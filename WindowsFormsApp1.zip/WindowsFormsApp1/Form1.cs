﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        private static Bitmap mBitmap;
        private static byte[,] mGrayPixels;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            mBitmap = new Bitmap("../../testImage.jpg");

            mGrayPixels = new byte[mBitmap.Height, mBitmap.Width];
            pictureBox1.Image = mBitmap;

            int width = mBitmap.Width;
            int height = mBitmap.Height;

            BitmapData bmData = mBitmap.LockBits(new Rectangle(0, 0, width, height), ImageLockMode.ReadWrite, PixelFormat.Format24bppRgb);
            int Offset = bmData.Stride - width * 3;

            System.IntPtr Scan0 = bmData.Scan0;

            unsafe
            {
                byte* p = (byte*)(void*)Scan0;

                for (int y = 0; y < height; ++y)
                {
                    for (int x = 0; x < width; ++x)
                    {
                        byte blue = p[0];
                        byte green = p[1];
                        byte red = p[2];

                        p[0] = p[1] = p[2] = (byte)(.299 * red + .587 * green + .114 * blue);

                        p += 3;
                    }
                    p += Offset;
                }
            }
            mBitmap.UnlockBits(bmData);

            /*
            for (int y = 0; y < height; ++y)
            {
                for (int x = 0; x < width; ++x)
                {
                    Color color = mBitmap.GetPixel(x, y);
                    byte gray = (byte)(color.R * 0.299 + color.G * 0.587 + color.B * 0.114);
                    mGrayPixels[y, x] = gray;
                }
            }

            for (int y = 0; y < height; ++y)
            { 
                for (int x = 0; x < width; ++x)
                {
                    byte gray = mGrayPixels[y, x];
                    Color color = Color.FromArgb(gray, gray, gray);
                    mBitmap.SetPixel(x, y, color);
                }
            }
            */
        }
    }
}
