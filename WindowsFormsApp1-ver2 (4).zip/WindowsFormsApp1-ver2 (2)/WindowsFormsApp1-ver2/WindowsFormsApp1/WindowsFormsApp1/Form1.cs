﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        private static Bitmap mBitmap;
        private static byte[,] mGrayPixels;

        private static int KERNAL_SIZE = 5;
        private static int RGB_TO_GRAY = 3;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            pictureBox1.Image = null;

            mBitmap = new Bitmap("../../testImage10.jpg");
            mGrayPixels = getGrayPixels();
        }

        private byte[,] getGrayPixels()
        {
            int height = mBitmap.Height;
            int width = mBitmap.Width;

            byte[,] grayPixels = new byte[height, width];

            Rectangle rect = new Rectangle(0, 0, width, height);
            BitmapData bmpData = mBitmap.LockBits(rect, System.Drawing.Imaging.ImageLockMode.ReadWrite, mBitmap.PixelFormat);

            IntPtr ptr = bmpData.Scan0;

            int bytes = Math.Abs(bmpData.Stride) * height;

            byte[] buffer = new byte[bytes];
            grayPixels = new byte[height, width];

            Marshal.Copy(ptr, buffer, 0, bytes);

            for (int counter = 0; counter < buffer.Length; counter += 3)
            {
                byte g = buffer[counter];
                byte b = buffer[counter + 1];
                byte r = buffer[counter + 2];

                byte gray = (byte)(0.299 * r + 0.587 * g + 0.114 * b);

                buffer[counter] = gray;
            }

            mBitmap.UnlockBits(bmpData);

            pictureBox1.Image = mBitmap;

            for (int y = 0; y < height; ++y)
            {
                for (int x = 0; x < width; ++x)
                {
                    grayPixels[y, x] = buffer[(y * bmpData.Stride) + (x * RGB_TO_GRAY)];
                }
            }

            return grayPixels;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            pictureBox1.Image = null;

            int height = mGrayPixels.GetLength(0);
            int width = mGrayPixels.GetLength(1);

            ulong mean = 0;
            for (int y = 0; y < height; ++y)
            {
                for (int x = 0; x < width; ++x)
                {
                    mean += mGrayPixels[y, x];
                }
            }
            mean = mean / (ulong)(width * height);

            byte[,] binaryPixels = new byte[height, width];
            for (int y = 0; y < height; ++y)
            {
                for (int x = 0; x < width; ++x)
                {
                    if (mGrayPixels[y, x] > mean)
                    {
                        binaryPixels[y, x] = 255;
                    }
                    else
                    {
                        binaryPixels[y, x] = 0;
                    }
                }
            }

            drawBitmapWithBuffered(binaryPixels);

            pictureBox1.Image = mBitmap;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            pictureBox1.Image = null;

            // mGrayPixels = getGrayPixels();
            drawBitmapWithBuffered(mGrayPixels);

            pictureBox1.Image = mBitmap;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Debug.Assert(mBitmap.Width >= KERNAL_SIZE && mBitmap.Height >= KERNAL_SIZE);

            pictureBox1.Image = null;

            int width = mBitmap.Width;
            int height = mBitmap.Height;

            int verticalCount = height / KERNAL_SIZE;
            int horizontalCount = width / KERNAL_SIZE;
            int remainingVerticalCount = height % KERNAL_SIZE;
            int remainingHorizontalCount = width % KERNAL_SIZE;

            byte[,] binaryPixels = new byte[height, width];

            for (int verticalIndex = 0; verticalIndex < verticalCount; ++verticalIndex)
            {
                ulong mean = 0;

                for (int horizontalIndex = 0; horizontalIndex < horizontalCount; ++horizontalIndex)
                {
                    mean = 0;
                    for (int y = 0; y < KERNAL_SIZE; ++y)
                    {
                        for (int x = 0; x < KERNAL_SIZE; ++x)
                        {
                            int yIndex = KERNAL_SIZE * verticalIndex + y;
                            int xIndex = KERNAL_SIZE * horizontalIndex + x;

                            mean = mean + mGrayPixels[yIndex, xIndex];
                        }
                    }
                    mean = mean / (ulong)(KERNAL_SIZE * KERNAL_SIZE);

                    for (int y = 0; y < KERNAL_SIZE; ++y)
                    {
                        for (int x = 0; x < KERNAL_SIZE; ++x)
                        {
                            int yIndex = KERNAL_SIZE * verticalIndex + y;
                            int xIndex = KERNAL_SIZE * horizontalIndex + x;

                            if (mGrayPixels[yIndex, xIndex] > mean)
                            {
                                binaryPixels[yIndex, xIndex] = 255;
                            }
                            else
                            {
                                binaryPixels[yIndex, xIndex] = 0;
                            }
                        }
                    }
                }

                mean = 0;
                for (int y = 0; y < remainingVerticalCount; ++y)
                {
                    for (int x = 0; x < width - remainingHorizontalCount; ++x)
                    {
                        int startY = KERNAL_SIZE * verticalCount;

                        mean = mean + mGrayPixels[startY + y, x];
                    }
                }
                mean = mean / (ulong)(KERNAL_SIZE * KERNAL_SIZE);

                for (int y = 0; y < remainingVerticalCount; ++y)
                {
                    for (int x = 0; x < width - remainingHorizontalCount; ++x)
                    {
                        int startY = KERNAL_SIZE * verticalCount;

                        if (mGrayPixels[startY + y, x] > mean)
                        {
                            binaryPixels[startY + y, x] = 255;
                        }
                        else
                        {
                            binaryPixels[startY + y, x] = 0;
                        }
                    }
                }

                mean = 0;
                for (int y = 0; y < height - remainingVerticalCount; ++y)
                {
                    for (int x = 0; x < remainingHorizontalCount; ++x)
                    {
                        int startX = KERNAL_SIZE * horizontalCount;

                        mean = mean + mGrayPixels[y, startX + x];
                    }
                }
                mean = mean / (ulong)(KERNAL_SIZE * KERNAL_SIZE);

                for (int y = 0; y < height - remainingVerticalCount; ++y)
                {
                    for (int x = 0; x < remainingHorizontalCount; ++x)
                    {
                        int startX = KERNAL_SIZE * horizontalCount;

                        if (mGrayPixels[y, startX + x] > mean)
                        {
                            binaryPixels[y, startX + x] = 255;
                        }
                        else
                        {
                            binaryPixels[y, startX + x] = 0;
                        }
                    }
                }

                mean = 0;
                for (int y = 0; y < remainingVerticalCount; ++y)
                {
                    for (int x = 0; x < remainingHorizontalCount; ++x)
                    {
                        int startY = KERNAL_SIZE * verticalCount;
                        int startX = KERNAL_SIZE * horizontalCount;

                        mean = mean + mGrayPixels[startY + y, startX + x];
                    }
                }
                mean = mean / (ulong)(KERNAL_SIZE * KERNAL_SIZE);

                for (int y = 0; y < remainingVerticalCount; ++y)
                {
                    for (int x = 0; x < remainingHorizontalCount; ++x)
                    {
                        int startY = KERNAL_SIZE * verticalCount;
                        int startX = KERNAL_SIZE * horizontalCount;

                        if (mGrayPixels[startY + y, startX + x] > mean)
                        {
                            binaryPixels[startY + y, startX + x] = 255;
                        }
                        else
                        {
                            binaryPixels[startY + y, startX + x] = 0;
                        }
                    }
                }
            }

            drawBitmapWithBuffered(binaryPixels);

            pictureBox1.Image = mBitmap;
        }

        private void drawBitmapWithBuffered(byte[,] pixels)
        {
            int width = mBitmap.Width;
            int height = mBitmap.Height;

            Rectangle rect = new Rectangle(0, 0, width, height);
            BitmapData bmpData = mBitmap.LockBits(rect, ImageLockMode.ReadWrite, mBitmap.PixelFormat);

            IntPtr ptr = bmpData.Scan0;

            int bytes = Math.Abs(bmpData.Stride) * height;
            byte[] buffer = new byte[bytes];

            for (int y = 0; y < height; ++y)
            {
                for (int x = 0; x < width; ++x)
                {
                    buffer[(y * bmpData.Stride) + (x * RGB_TO_GRAY)] = pixels[y, x];
                    buffer[(y * bmpData.Stride) + (x * RGB_TO_GRAY) + 1] = pixels[y, x];
                    buffer[(y * bmpData.Stride) + (x * RGB_TO_GRAY) + 2] = pixels[y, x];
                }
            }

            Marshal.Copy(buffer, 0, ptr, bytes);

            mBitmap.UnlockBits(bmpData);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            pictureBox1.Image = null;

            int[] histogram = new int[256];

            int height = mGrayPixels.GetLength(0);
            int width = mGrayPixels.GetLength(1);

            for (int y = 0; y < height; ++y)
            {
                for (int x = 0; x < width; ++x)
                {
                    byte gray = mGrayPixels[y, x];
                    histogram[gray]++;
                }
            }

            int sum = 0;
            for (int i = 1; i < histogram.Length; ++i)
            {
                sum += histogram[i];
            }
            // Debug.Assert(sum == width * height);

            sum = 0;

            byte[] equalizedHistogram = new byte[256];
            for (int i = 1; i < histogram.Length; ++i)
            {
                sum = sum + histogram[i];
                equalizedHistogram[i] = (byte)Math.Round(sum * 255.0 / (width * height));
            }

            for (int y = 0; y < height; ++y)
            {
                for (int x = 0; x < width; ++x)
                {
                    byte gray = mGrayPixels[y, x];
                    mGrayPixels[y, x] = equalizedHistogram[gray];
                }
            }

            drawBitmapWithBuffered(mGrayPixels);
            pictureBox1.Image = mBitmap;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            pictureBox1.Image = null;

            int[,] xMask3x3 = new int[,] 
            {
                { -1, 0, 1 },
                { -2, 0, 2 },
                { -1, 0, 1 }
            };

            int[,] yMask3x3 = new int[,]
            {
                { 1, 2, 1 },
                { 0, 0, 0 },
                {-1,-2,-1 }
            };

            int height = mGrayPixels.GetLength(0);
            int width = mGrayPixels.GetLength(1);

            byte[,] binaryPixels = new byte[height, width];

            for (int maskCenterYIndex = 1; maskCenterYIndex < height - 1; ++maskCenterYIndex)
            {
                for (int maskCenterXIndex = 1; maskCenterXIndex < width - 1; ++maskCenterXIndex)
                {
                    int maskXSum = 0;
                    int maskYSum = 0;
                    int maskSum = 0;

                    maskXSum += xMask3x3[(maskCenterYIndex - 1) % 3, (maskCenterXIndex + 1) % 3] * mGrayPixels[maskCenterYIndex - 1, maskCenterXIndex + 1];
                    maskXSum += xMask3x3[(maskCenterYIndex    ) % 3, (maskCenterXIndex + 1) % 3] * mGrayPixels[maskCenterYIndex,     maskCenterXIndex + 1];
                    maskXSum += xMask3x3[(maskCenterYIndex + 1) % 3, (maskCenterXIndex + 1) % 3] * mGrayPixels[maskCenterYIndex + 1, maskCenterXIndex + 1];
                    maskXSum += xMask3x3[(maskCenterYIndex - 1) % 3, (maskCenterXIndex    ) % 3] * mGrayPixels[maskCenterYIndex - 1, maskCenterXIndex    ];
                    maskXSum += xMask3x3[(maskCenterYIndex    ) % 3, (maskCenterXIndex    ) % 3] * mGrayPixels[maskCenterYIndex    , maskCenterXIndex    ];
                    maskXSum += xMask3x3[(maskCenterYIndex + 1) % 3, (maskCenterXIndex    ) % 3] * mGrayPixels[maskCenterYIndex + 1, maskCenterXIndex    ];
                    maskXSum += xMask3x3[(maskCenterYIndex - 1) % 3, (maskCenterXIndex - 1) % 3] * mGrayPixels[maskCenterYIndex - 1, maskCenterXIndex - 1];
                    maskXSum += xMask3x3[(maskCenterYIndex    ) % 3, (maskCenterXIndex - 1) % 3] * mGrayPixels[maskCenterYIndex    , maskCenterXIndex - 1];
                    maskXSum += xMask3x3[(maskCenterYIndex + 1) % 3, (maskCenterXIndex - 1) % 3] * mGrayPixels[maskCenterYIndex + 1, maskCenterXIndex - 1];
                                                                                                
                    maskYSum += xMask3x3[(maskCenterYIndex - 1) % 3, (maskCenterXIndex + 1) % 3] * mGrayPixels[maskCenterYIndex - 1, maskCenterXIndex + 1];
                    maskYSum += xMask3x3[(maskCenterYIndex    ) % 3, (maskCenterXIndex + 1) % 3] * mGrayPixels[maskCenterYIndex    , maskCenterXIndex + 1];
                    maskYSum += xMask3x3[(maskCenterYIndex + 1) % 3, (maskCenterXIndex + 1) % 3] * mGrayPixels[maskCenterYIndex + 1, maskCenterXIndex + 1];
                    maskYSum += xMask3x3[(maskCenterYIndex - 1) % 3, (maskCenterXIndex    ) % 3] * mGrayPixels[maskCenterYIndex - 1, maskCenterXIndex    ];
                    maskYSum += xMask3x3[(maskCenterYIndex    ) % 3, (maskCenterXIndex    ) % 3] * mGrayPixels[maskCenterYIndex    , maskCenterXIndex    ];
                    maskYSum += xMask3x3[(maskCenterYIndex + 1) % 3, (maskCenterXIndex    ) % 3] * mGrayPixels[maskCenterYIndex + 1, maskCenterXIndex    ];
                    maskYSum += xMask3x3[(maskCenterYIndex - 1) % 3, (maskCenterXIndex - 1) % 3] * mGrayPixels[maskCenterYIndex - 1, maskCenterXIndex - 1];
                    maskYSum += xMask3x3[(maskCenterYIndex    ) % 3, (maskCenterXIndex - 1) % 3] * mGrayPixels[maskCenterYIndex    , maskCenterXIndex - 1];
                    maskYSum += xMask3x3[(maskCenterYIndex + 1) % 3, (maskCenterXIndex - 1) % 3] * mGrayPixels[maskCenterYIndex + 1, maskCenterXIndex - 1];

                    maskSum = Math.Abs(maskXSum) + Math.Abs(maskYSum); 

                    if (maskSum > 80)
                    {
                        binaryPixels[maskCenterYIndex, maskCenterXIndex] = 0;
                    }
                    else
                    {
                        binaryPixels[maskCenterYIndex, maskCenterXIndex] = 255;
                    }
                }
            }

            drawBitmapWithBuffered(binaryPixels);
            pictureBox1.Image = mBitmap;
        }
    }
}
