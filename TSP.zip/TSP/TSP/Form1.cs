﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace TSP
{
    public partial class Form1 : Form
    {
        private List<Point> mCityCoords;
        private List<int[]> citiesList;
        private Point mStartPoint;
        private Graphics mGraphics;
        private Random mRandom;

        private readonly int CITY_COUNT = 30;               // 도시 개수
        private readonly int MODEL_PER_GENERATION = 128;   // 세대 당 도시리스트(유전자) 개수
        private readonly int MAX_GENERATION_COUNT = 3000;   // 최대 세대 수
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        public int[] GetOrder1CrossOver(int[] cities1, int[] cities2, int start, int end)
        {
            Debug.Assert(cities1.Length == cities2.Length);
            Debug.Assert(start >= 0 && start < cities1.Length);
            Debug.Assert(end >= 0 && end < cities1.Length);
            Debug.Assert(start <= end);

            int length = cities1.Length;

            int[] newCities = new int[length];

            for (int i = start; i <= end; i++)
            {
                newCities[i] = cities2[i];
            }

            int idx = end + 1;

            for (int i = 0; i < length; i++)
            {
                bool bOverlap = false;

                for (int j = start; j <= end; j++)
                {
                    if (cities1[i] == newCities[j])
                    {
                        bOverlap = true;
                    }
                }

                if (!bOverlap)
                {
                    newCities[idx++ % length] = cities1[i];
                }
            }

            return newCities;
        }
        private int GetTotalDistance(int[] cities)
        {
            Debug.Assert(mCityCoords != null);

            double distance = 0;

            double diffX = Math.Abs(mStartPoint.X - mCityCoords[cities[0]].X);
            double diffY = Math.Abs(mStartPoint.Y - mCityCoords[cities[0]].Y);
            distance += Math.Sqrt(Math.Pow(diffX, 2) + Math.Pow(diffY, 2));

            diffX = Math.Abs(mStartPoint.X - mCityCoords[cities[cities.Length - 1]].X);
            diffY = Math.Abs(mStartPoint.Y - mCityCoords[cities[cities.Length - 1]].Y);
            distance += Math.Sqrt(Math.Pow(diffX, 2) + Math.Pow(diffY, 2));

            for (int i = 0; i < cities.Length - 1; i++)
            {
                int city1 = cities[i];
                int city2 = cities[i + 1];
                Point p1 = mCityCoords[city1];
                Point p2 = mCityCoords[city2];

                distance += Math.Sqrt(Math.Pow(p1.X - p2.X, 2) + Math.Pow(p1.Y - p2.Y, 2));
            }

            return (int)distance;
        }

        private static List<Point> loadCityCoords(string filePath)
        {
            string[] lines = File.ReadAllLines(filePath);
            List<Point> cityCoords = new List<Point>(lines.Length);

            foreach (var line in lines)
            {
                string[] split = line.Split();
                int x = int.Parse(split[0]);
                int y = int.Parse(split[1]);

                cityCoords.Add(new Point(x, y));
            }

            return cityCoords;
        }

        private void changeCityOrder(int[] cities)
        {
            int start = mRandom.Next(1, cities.Length - 4);
            int length = 4;

            for (int i = start + length - 1; i >= start; i--)
            {
                int randInt = mRandom.Next(start, i);

                int temp = cities[i];
                cities[i] = cities[randInt];
                cities[randInt] = temp;
            }
        }

        private void Draw(int[] cities, Point start)
        {
            mGraphics = pictureBox1.CreateGraphics();
            Pen dotPen = new Pen(Color.Red);
            Pen linePen = new Pen(Color.Black);

            int width = 5;
            int height = 5;

            mGraphics.DrawEllipse(new Pen(Color.Orange), start.X + 450 - 10, start.Y + 390, 20, 20);

            for (int i = 0; i < cities.Length; i++)
            {
                mGraphics.DrawEllipse(dotPen, mCityCoords[cities[i]].X + 450 - 2.5f, mCityCoords[cities[i]].Y + 390 - 2.5f, width, height);
            }

            for (int i = 0; i < cities.Length - 1; i++)
            {
                mGraphics.DrawLine(linePen, mCityCoords[cities[i]].X + 450, mCityCoords[cities[i]].Y + 390, mCityCoords[cities[i + 1]].X + 450, mCityCoords[cities[i + 1]].Y + 390);
            }

            // mGraphics.DrawLine(new Pen(Color.Orange), start.X + 450, start.Y + 390, end.X + 450, end.Y + 390);
            mGraphics.DrawLine(new Pen(Color.Orange), start.X + 450, start.Y + 390, mCityCoords[cities[0]].X + 450, mCityCoords[cities[0]].Y + 390);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (mGraphics != null)
            {
                mGraphics.Clear(BackColor);
            }

            mCityCoords = loadCityCoords(@"..\..\..\..\cities" + CITY_COUNT + ".txt");

            mStartPoint = mCityCoords[0];
            mCityCoords.RemoveAt(0);

            citiesList = new List<int[]>(MODEL_PER_GENERATION);

            // 랜덤순서로 도시를 방문하는 Visitor의 배열 생성
            mRandom = new Random();

            for (int i = 0; i < MODEL_PER_GENERATION; i++)
            {
                int[] cities = new int[mCityCoords.Count];

                for (int j = 0; j < mCityCoords.Count; j++)
                {
                    cities[j] = j;
                }

                // shuffle
                for (int j = cities.Length - 1; j >= 1; j--)
                {
                    int randInt = mRandom.Next(0, j);

                    int temp = cities[j];
                    cities[j] = cities[randInt];
                    cities[randInt] = temp;
                }

                citiesList.Add(cities);
            }

            uint generation = 0;
            while (true)
            {
                citiesList.Sort((cities1, cities2) =>
                {
                    return GetTotalDistance(cities1) - GetTotalDistance(cities2);
                });

                if (generation % 100 == 0)
                {
                    Application.DoEvents();
                    textBox2.Text = $"{generation} / {MAX_GENERATION_COUNT}";
                    textBox1.Text = $"{GetTotalDistance(citiesList[0])}";
                }

                if (generation++ == MAX_GENERATION_COUNT)
                {
                    textBox1.Text = $"{GetTotalDistance(citiesList[0])}";
                    break;
                }

                List<int[]> newCitiesList = new List<int[]>(MODEL_PER_GENERATION);

                uint count = 0;

                // 엘리트 보존
                newCitiesList.Add(citiesList[0]);
                newCitiesList.Add(citiesList[1]);

                for (int i = 0; i < citiesList.Count; i++)
                {
                    for (int j = 0; j < citiesList.Count; j++)
                    {
                        int start = mRandom.Next(citiesList[i].Length - 1);
                        int end = mRandom.Next(start, citiesList[i].Length);
                        // 순서 교차
                        newCitiesList.Add(GetOrder1CrossOver(citiesList[i], citiesList[j], start, end));
                        newCitiesList.Add(GetOrder1CrossOver(citiesList[i], citiesList[j], start, end));

                        count += 2;

                        if (count == MODEL_PER_GENERATION)
                        {
                            goto loop_exit;
                        }
                    }
                }

            loop_exit:

                // 돌연변이
                for (int i = citiesList.Count - 1; i >= citiesList.Count / 5; i--)
                {
                    changeCityOrder(citiesList[i]);
                }

                for (int i = 0; i < citiesList.Count; i++)
                {
                    citiesList[i] = (int[])newCitiesList[i].Clone();
                }
            }

            Draw(citiesList[0], mStartPoint);
        }
    }
}
