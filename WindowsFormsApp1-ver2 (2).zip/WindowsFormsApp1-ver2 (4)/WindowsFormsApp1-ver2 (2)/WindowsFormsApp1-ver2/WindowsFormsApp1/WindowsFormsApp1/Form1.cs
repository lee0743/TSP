﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        private static Bitmap mBitmap;
        private static byte[,] mGrayPixels;

        private static int KERNAL_SIZE = 3;
        private static int RGB_TO_GRAY = 3;

        private static int SOBEL_THRESHOLD = 100;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            pictureBox1.Image = null;

            mBitmap = new Bitmap("../../testImage12.jpg");
            mGrayPixels = getGrayPixels();
        }

        private byte[,] getGrayPixels()
        {
            int height = mBitmap.Height;
            int width = mBitmap.Width;

            byte[,] grayPixels = new byte[height, width];

            Rectangle rect = new Rectangle(0, 0, width, height);
            BitmapData bmpData = mBitmap.LockBits(rect, System.Drawing.Imaging.ImageLockMode.ReadWrite, mBitmap.PixelFormat);

            IntPtr ptr = bmpData.Scan0;

            int bytes = Math.Abs(bmpData.Stride) * height;

            byte[] buffer = new byte[bytes];
            grayPixels = new byte[height, width];

            Marshal.Copy(ptr, buffer, 0, bytes);

            for (int counter = 0; counter < buffer.Length; counter += 3)
            {
                byte g = buffer[counter];
                byte b = buffer[counter + 1];
                byte r = buffer[counter + 2];

                byte gray = (byte)(0.299 * r + 0.587 * g + 0.114 * b);

                buffer[counter] = gray;
            }

            mBitmap.UnlockBits(bmpData);

            pictureBox1.Image = mBitmap;

            for (int y = 0; y < height; ++y)
            {
                for (int x = 0; x < width; ++x)
                {
                    grayPixels[y, x] = buffer[(y * bmpData.Stride) + (x * RGB_TO_GRAY)];
                }
            }

            return grayPixels;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            pictureBox1.Image = null;

            int height = mGrayPixels.GetLength(0);
            int width = mGrayPixels.GetLength(1);

            ulong mean = 0;
            for (int y = 0; y < height; ++y)
            {
                for (int x = 0; x < width; ++x)
                {
                    mean += mGrayPixels[y, x];
                }
            }
            mean = mean / (ulong)(width * height);

            byte[,] binaryPixels = new byte[height, width];
            for (int y = 0; y < height; ++y)
            {
                for (int x = 0; x < width; ++x)
                {
                    if (mGrayPixels[y, x] > mean)
                    {
                        binaryPixels[y, x] = 255;
                    }
                    else
                    {
                        binaryPixels[y, x] = 0;
                    }
                }
            }

            drawBitmapWithBuffered(binaryPixels);

            pictureBox1.Image = mBitmap;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            pictureBox1.Image = null;

            // mGrayPixels = getGrayPixels();
            drawBitmapWithBuffered(mGrayPixels);

            pictureBox1.Image = mBitmap;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Debug.Assert(mBitmap.Width >= KERNAL_SIZE && mBitmap.Height >= KERNAL_SIZE);

            pictureBox1.Image = null;

            int[,] mask3x3 = new int[,]
            {
                { 1, 1, 1 },
                { 1, 1, 1 },
                { 1, 1, 1 }
            };

            int height = mGrayPixels.GetLength(0);
            int width = mGrayPixels.GetLength(1);

            byte[,] binaryPixels = new byte[height, width];

            for (int maskCenterYIndex = 1; maskCenterYIndex < height - 1; ++maskCenterYIndex)
            {
                for (int maskCenterXIndex = 1; maskCenterXIndex < width - 1; ++maskCenterXIndex)
                {
                    int mean = 0;

                    for (int maskYOffset = -1; maskYOffset <= 1; ++maskYOffset)
                    {
                        for (int maskXOffset = -1; maskXOffset <= 1; ++maskXOffset)
                        {
                            mean += mask3x3[maskYOffset + 1, maskXOffset + 1] * mGrayPixels[maskCenterYIndex + maskYOffset, maskCenterXIndex + maskXOffset];
                        }
                    }

                    mean /= (3 * 3);

                    if (mGrayPixels[maskCenterYIndex, maskCenterXIndex] > mean)
                    {
                        binaryPixels[maskCenterYIndex, maskCenterXIndex] = 255;
                    }
                    else
                    {
                        binaryPixels[maskCenterYIndex, maskCenterXIndex] = 0;
                    }
                }
            }

            drawBitmapWithBuffered(binaryPixels);
            pictureBox1.Image = mBitmap;

            drawBitmapWithBuffered(binaryPixels);

            pictureBox1.Image = mBitmap;
        }

        private void drawBitmapWithBuffered(byte[,] pixels)
        {
            int width = mBitmap.Width;
            int height = mBitmap.Height;

            Rectangle rect = new Rectangle(0, 0, width, height);
            BitmapData bmpData = mBitmap.LockBits(rect, ImageLockMode.ReadWrite, mBitmap.PixelFormat);

            IntPtr ptr = bmpData.Scan0;

            int bytes = Math.Abs(bmpData.Stride) * height;
            byte[] buffer = new byte[bytes];

            for (int y = 0; y < height; ++y)
            {
                for (int x = 0; x < width; ++x)
                {
                    buffer[(y * bmpData.Stride) + (x * RGB_TO_GRAY)] = pixels[y, x];
                    buffer[(y * bmpData.Stride) + (x * RGB_TO_GRAY) + 1] = pixels[y, x];
                    buffer[(y * bmpData.Stride) + (x * RGB_TO_GRAY) + 2] = pixels[y, x];
                }
            }

            Marshal.Copy(buffer, 0, ptr, bytes);

            mBitmap.UnlockBits(bmpData);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            pictureBox1.Image = null;

            int[] histogram = new int[256];

            int height = mGrayPixels.GetLength(0);
            int width = mGrayPixels.GetLength(1);

            for (int y = 0; y < height; ++y)
            {
                for (int x = 0; x < width; ++x)
                {
                    byte gray = mGrayPixels[y, x];
                    histogram[gray]++;
                }
            }

            int sum = 0;
            for (int i = 1; i < histogram.Length; ++i)
            {
                sum += histogram[i];
            }
            // Debug.Assert(sum == width * height);

            sum = 0;

            byte[] equalizedHistogram = new byte[256];
            for (int i = 1; i < histogram.Length; ++i)
            {
                sum = sum + histogram[i];
                equalizedHistogram[i] = (byte)Math.Round(sum * 255.0 / (width * height));
            }

            for (int y = 0; y < height; ++y)
            {
                for (int x = 0; x < width; ++x)
                {
                    byte gray = mGrayPixels[y, x];
                    mGrayPixels[y, x] = equalizedHistogram[gray];
                }
            }

            drawBitmapWithBuffered(mGrayPixels);
            pictureBox1.Image = mBitmap;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            pictureBox1.Image = null;

            int[,] xMask3x3 = new int[,] 
            {
                { -1, 0, 1 },
                { -2, 0, 2 },
                { -1, 0, 1 }
            };

            int[,] yMask3x3 = new int[,]
            {
                { 1, 2, 1 },
                { 0, 0, 0 },
                {-1,-2,-1 }
            };

            int height = mGrayPixels.GetLength(0);
            int width = mGrayPixels.GetLength(1);

            byte[,] binaryPixels = new byte[height, width];

            for (int maskCenterYIndex = 1; maskCenterYIndex < height - 1; ++maskCenterYIndex)
            {
                for (int maskCenterXIndex = 1; maskCenterXIndex < width - 1; ++maskCenterXIndex)
                {
                    int maskXSum = 0;
                    int maskYSum = 0;

                    for (int maskYOffset = -1; maskYOffset <= 1; ++maskYOffset)
                    {
                        for (int maskXOffset = -1; maskXOffset <= 1; ++maskXOffset)
                        {
                            maskXSum += xMask3x3[maskYOffset + 1, maskXOffset + 1] * mGrayPixels[maskCenterYIndex + maskYOffset, maskCenterXIndex + maskXOffset];
                            maskYSum += yMask3x3[maskYOffset + 1, maskXOffset + 1] * mGrayPixels[maskCenterYIndex + maskYOffset, maskCenterXIndex + maskXOffset];
                        }
                    }

                    int maskSum = Math.Abs(maskXSum) + Math.Abs(maskYSum);

                    if (maskSum > SOBEL_THRESHOLD)
                    {
                        binaryPixels[maskCenterYIndex, maskCenterXIndex] = 0;
                    }
                    else
                    {
                        binaryPixels[maskCenterYIndex, maskCenterXIndex] = 255;
                    }
                }
            }

            drawBitmapWithBuffered(binaryPixels);
            pictureBox1.Image = mBitmap;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Debug.Assert(mBitmap.Width >= KERNAL_SIZE && mBitmap.Height >= KERNAL_SIZE);

            pictureBox1.Image = null;

            int[,] mask3x3 = new int[,]
            {
                { 1, 2, 1 },
                { 2, 4, 2 },
                { 1, 2, 1 }
            };

            int height = Form1.mGrayPixels.GetLength(0);
            int width = Form1.mGrayPixels.GetLength(1);

            for (int maskCenterYIndex = 1; maskCenterYIndex < height - 1; ++maskCenterYIndex)
            {
                for (int maskCenterXIndex = 1; maskCenterXIndex < width - 1; ++maskCenterXIndex)
                {
                    int weightedMean = 0;

                    for (int maskYOffset = -1; maskYOffset <= 1; ++maskYOffset)
                    {
                        for (int maskXOffset = -1; maskXOffset <= 1; ++maskXOffset)
                        {
                            weightedMean += mask3x3[maskYOffset + 1, maskXOffset + 1] * Form1.mGrayPixels[maskCenterYIndex + maskYOffset, maskCenterXIndex + maskXOffset];
                        }
                    }

                    weightedMean /= 16;
                    mGrayPixels[maskCenterYIndex, maskCenterXIndex] = (byte)weightedMean;
                }
            }

            drawBitmapWithBuffered(mGrayPixels);
            pictureBox1.Image = mBitmap;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Debug.Assert(mBitmap.Width >= KERNAL_SIZE && mBitmap.Height >= KERNAL_SIZE);

            pictureBox1.Image = null;

            int[,] mask7x7 = new int[,]
            {
                {  1,  4,  7, 10,  7,  4,  1 },
                {  4, 12, 26, 33, 26, 12,  4 },
                {  7, 26, 55, 71, 55, 26,  7 },
                { 10, 33, 71, 91, 71, 33, 10 },
                {  7, 26, 55, 71, 55, 26,  7 },
                {  4, 12, 26, 33, 26, 12,  4 },
                {  1,  4,  7, 10,  7,  4,  1 }
            };

            int height = Form1.mGrayPixels.GetLength(0);
            int width = Form1.mGrayPixels.GetLength(1);

            for (int maskCenterYIndex = 1; maskCenterYIndex < height - 7 + 1; ++maskCenterYIndex)
            {
                for (int maskCenterXIndex = 1; maskCenterXIndex < width - 7 + 1; ++maskCenterXIndex)
                {
                    int weightedMean = 0;

                    for (int maskYOffset = 0; maskYOffset < 7; ++maskYOffset)
                    {
                        for (int maskXOffset = 0; maskXOffset < 7; ++maskXOffset)
                        {
                            weightedMean += mask7x7[maskYOffset, maskXOffset] * 
                                Form1.mGrayPixels[maskCenterYIndex + maskYOffset - 1, maskCenterXIndex + maskXOffset - 1];
                        }
                    }

                    weightedMean /= 1115;
                    mGrayPixels[maskCenterYIndex, maskCenterXIndex] = (byte)weightedMean;
                }
            }

            drawBitmapWithBuffered(mGrayPixels);
            pictureBox1.Image = mBitmap;
        }
    }
}
