﻿namespace WindowsFormsApp1
{
    public enum EBinaryColor
    {
        BLACK = 255,
        WHITE = 0
    }
}
