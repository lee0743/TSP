﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        private static Bitmap mBitmap;
        private static byte[] mPixels;
        private static byte[,] mGrayPixels;

        private static int RGBToGray = 3;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            pictureBox1.Image = null;

            mBitmap = new Bitmap("../../testImage2.jpg");

            int height = mBitmap.Height;
            int width = mBitmap.Width;
            
            mGrayPixels = new byte[height, width];

            Rectangle rect = new Rectangle(0, 0, width, height);
            BitmapData bmpData = mBitmap.LockBits(rect, System.Drawing.Imaging.ImageLockMode.ReadWrite, mBitmap.PixelFormat);

            IntPtr ptr = bmpData.Scan0;

            int bytes = Math.Abs(bmpData.Stride) * height;

            mPixels = new byte[bytes];
            mGrayPixels = new byte[height, width];

            Marshal.Copy(ptr, mPixels, 0, bytes);

            for (int counter = 0; counter < mPixels.Length; counter += 3)
            {
                byte g = mPixels[counter];
                byte b = mPixels[counter + 1];
                byte r = mPixels[counter + 2];

                byte gray = (byte)(0.299 * r + 0.587 * g + 0.114 * b);

                mPixels[counter] = gray;
                mPixels[counter + 1] = gray;
                mPixels[counter + 2] = gray;
            }

            Marshal.Copy(mPixels, 0, ptr, bytes);

            mBitmap.UnlockBits(bmpData);

            pictureBox1.Image = mBitmap;

            for (int y = 0; y < height; ++y)
            {
                for (int x = 0; x < width; ++x)
                {
                    mGrayPixels[y, x] = mPixels[(y * bmpData.Stride) + (x * RGBToGray)];
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            pictureBox1.Image = null;
            
            int height = mGrayPixels.GetLength(0);
            int width = mGrayPixels.GetLength(1);

            ulong mean = 0;
            for (int y = 0; y < height; ++y)
            {
                for (int x = 0; x < width; ++x)
                {
                    mean += mGrayPixels[y, x];
                }
            }
            mean = mean / (ulong)(width * height);

            byte[,] binaryPixels = new byte[height, width];
            for (int y = 0; y < height; ++y)
            {
                for (int x = 0; x < width; ++x)
                {
                    if (mGrayPixels[y,x] > mean)
                    {
                        binaryPixels[y, x] = 255;
                    }
                    else
                    {
                        binaryPixels[y, x] = 0;
                    }
                }
            }

            Rectangle rect = new Rectangle(0, 0, width, height);
            BitmapData bmpData = mBitmap.LockBits(rect, ImageLockMode.ReadWrite, mBitmap.PixelFormat);

            IntPtr ptr = bmpData.Scan0;

            int bytes = Math.Abs(bmpData.Stride) * height;

            for (int y = 0; y < height; ++y)
            {
                for (int x = 0; x < width; ++x)
                {
                    mPixels[(y * bmpData.Stride) + (x * RGBToGray)] = binaryPixels[y, x];
                    mPixels[(y * bmpData.Stride) + (x * RGBToGray) + 1] = binaryPixels[y, x];
                    mPixels[(y * bmpData.Stride) + (x * RGBToGray) + 2] = binaryPixels[y, x];
                }
            }

            Marshal.Copy(mPixels, 0, ptr, bytes);

            mBitmap.UnlockBits(bmpData);

            pictureBox1.Image = mBitmap;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            pictureBox1.Image = null;

            int height = mGrayPixels.GetLength(0);
            int width = mGrayPixels.GetLength(1);

            Rectangle rect = new Rectangle(0, 0, width, height);
            BitmapData bmpData = mBitmap.LockBits(rect, ImageLockMode.ReadWrite, mBitmap.PixelFormat);

            IntPtr ptr = bmpData.Scan0;

            int bytes = Math.Abs(bmpData.Stride) * height;

            for (int y = 0; y < height; ++y)
            {
                for (int x = 0; x < width; ++x)
                {
                    mPixels[(y * bmpData.Stride) + (x * RGBToGray)] = mGrayPixels[y, x];
                    mPixels[(y * bmpData.Stride) + (x * RGBToGray) + 1] = mGrayPixels[y, x];
                    mPixels[(y * bmpData.Stride) + (x * RGBToGray) + 2] = mGrayPixels[y, x];
                }
            }

            Marshal.Copy(mPixels, 0, ptr, bytes);

            mBitmap.UnlockBits(bmpData);

            pictureBox1.Image = mBitmap;
        }
    }
}
